# Hotel Management System Consol Application
## Before running this program please make sure you have configured Dev-c++ with following steps.
1. Go to Tools -> Compiler Options -> "Compiler" tab
2. Check the checkbox labeled, "Add the following commands when calling the compiler" And add in the text entry box, "-std=c++11" or if that doesn't work "-std=C++0x"
3. Should be something like that anyway, I haven't had Dev C++ installed for many years, so I had to look at some screenshots on Google to remember.

# Demo Video

[![Hotel Management System Console Application Demo](https://img.youtube.com/vi/WEZl6fhUQvE/0.jpg)](https://www.youtube.com/watch?v=WEZl6fhUQvE)
